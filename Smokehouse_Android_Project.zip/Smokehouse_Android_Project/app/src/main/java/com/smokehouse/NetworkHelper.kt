package com.smokehouse

object NetworkHelper {
    // TODO: автоматический поиск Arduino по IP
}