package com.smokehouse

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class ProgramActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_program)
        // TODO: выбор программ A/B/C/D
    }
}